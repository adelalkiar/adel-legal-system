﻿@echo off
chcp 65001 >nul
title Adel Legal System - by Adel Al-Iraqi
cd /d "%~dp0"

echo ===================================================
echo    Al-Adel Legal Services System
echo    Developed by: Adel Al-Iraqi
echo ===================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js was not found on this computer.
    echo Please download and install Node.js from the link below,
    echo then run this file again:
    echo https://nodejs.org
    echo.
    pause
    exit /b
)

echo Node.js version:
node -v
echo.

if not exist "node_modules" (
    echo Preparing the program for the first time, please wait...
    echo This only happens once and requires an internet connection.
    echo.
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo [ERROR] Setup failed. Make sure you are connected to the internet
        echo and try again. If the problem continues, send a screenshot of
        echo this window to the developer.
        pause
        exit /b
    )
    echo.
    echo Setup completed successfully.
    echo.
)

echo Checking if port 3000 is already in use...
netstat -ano | findstr ":3000" | findstr "LISTENING" >nul
if %errorlevel% equ 0 (
    echo.
    echo [WARNING] Port 3000 is already in use by another program.
    echo This usually means the server is already running.
    echo Opening the browser now...
    timeout /t 2 /nobreak >nul
    start "" "http://localhost:3000"
    echo.
    echo If the page still does not open, restart your computer and try again.
    pause
    exit /b
)

echo Starting the server in a new window...
echo IMPORTANT: A second black window titled "Adel Legal System - Server"
echo will open and MUST stay open while you use the program.
echo If that window shows an error and closes, take a screenshot of it
echo and send it to the developer.
echo.

start "Adel Legal System - Server" cmd /k "chcp 65001>nul && node server.js"

echo Waiting for the server to start...
timeout /t 5 /nobreak >nul

start "" "http://localhost:3000"

echo.
echo The program should now be open in your browser.
echo If you see a connection error in the browser, check the second
echo window (Adel Legal System - Server) for an error message,
echo then take a screenshot of it and send it to the developer.
echo.
echo You can close THIS window now. Keep the server window open.
echo.
pause
